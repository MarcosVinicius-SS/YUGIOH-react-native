import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, Image,
  ScrollView, ActivityIndicator, Alert, StyleSheet, SafeAreaView,
} from 'react-native';

export default function App() {
  const [carta, setCarta] = useState(null);
  const [loading, setLoading] = useState(false);

  async function puxarCarta() {
    try {
      setLoading(true);
      const offset = Math.floor(Math.random() * 1000);
      const url = `https://db.ygoprodeck.com/api/v7/cardinfo.php?num=1&offset=${offset}`;
      const res = await fetch(`https://api.allorigins.win/get?url=${encodeURIComponent(url)}`);
      const json = await res.json();
      const data = JSON.parse(json.contents);

      if (!data.data || data.data.length === 0) {
        Alert.alert('Tente de novo', 'Nenhuma carta encontrada.');
        return;
      }

      setCarta(data.data[0]);
    } catch (e) {
      Alert.alert('Erro', e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <SafeAreaView style={s.safeArea}>
      <ScrollView contentContainerStyle={s.tela}>

        <Text style={s.titulo}>Meu Baralho</Text>
        <Text style={s.subtitulo}>Yu-Gi-Oh!</Text>

        <TouchableOpacity style={s.botao} onPress={puxarCarta} disabled={loading}>
          {loading
            ? <ActivityIndicator color="#111" />
            : <Text style={s.botaoTexto}>Puxar Carta</Text>
          }
        </TouchableOpacity>

        {carta ? (
          <View style={s.card}>
            <Image
              source={{ uri: `https://api.allorigins.win/raw?url=${encodeURIComponent(carta.card_images[0].image_url)}` }}
              style={s.imagem}
              resizeMode="contain"
            />
            <Text style={s.nome}>{carta.name}</Text>

            <View style={s.linha}>
              <Text style={s.badge}>{carta.type}</Text>
              {carta.attribute && <Text style={s.badge}>{carta.attribute}</Text>}
              {carta.level && <Text style={s.badge}>Nivel {carta.level}</Text>}
            </View>

            {(carta.atk !== undefined || carta.def !== undefined) && (
              <View style={s.statsRow}>
                <View style={s.stat}>
                  <Text style={s.statLabel}>ATK</Text>
                  <Text style={s.statValor}>{carta.atk ?? '?'}</Text>
                </View>
                <View style={s.divisor} />
                <View style={s.stat}>
                  <Text style={s.statLabel}>DEF</Text>
                  <Text style={s.statValor}>{carta.def ?? '?'}</Text>
                </View>
              </View>
            )}
          </View>
        ) : (
          <View style={s.vazio}>
            <Text style={s.vazioTexto}>Nenhuma carta puxada ainda.</Text>
          </View>
        )}

      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#111',
  },
  tela: {
    alignItems: 'center',
    padding: 20,
    paddingTop: 40,
    paddingBottom: 50,
  },
  titulo: {
    color: '#fff',
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  subtitulo: {
    color: '#f0c040',
    fontSize: 14,
    marginBottom: 30,
    letterSpacing: 3,
    textTransform: 'uppercase',
  },
  botao: {
    backgroundColor: '#f0c040',
    paddingHorizontal: 36,
    paddingVertical: 14,
    borderRadius: 8,
    marginBottom: 30,
    minWidth: 200,
    alignItems: 'center',
  },
  botaoTexto: {
    color: '#111',
    fontWeight: 'bold',
    fontSize: 15,
  },
  card: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 18,
    width: '100%',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#2a2a2a',
  },
  imagem: {
    width: 200,
    height: 290,
    borderRadius: 8,
    marginBottom: 18,
  },
  nome: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 12,
  },
  linha: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginBottom: 16,
  },
  badge: {
    backgroundColor: '#222',
    color: '#999',
    fontSize: 11,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 4,
    overflow: 'hidden',
    margin: 3,
    borderWidth: 1,
    borderColor: '#333',
  },
  statsRow: {
    flexDirection: 'row',
    backgroundColor: '#222',
    borderRadius: 8,
    paddingVertical: 14,
    paddingHorizontal: 20,
    marginBottom: 18,
    alignItems: 'center',
    width: '100%',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#2a2a2a',
  },
  stat: {
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  statLabel: {
    color: '#666',
    fontSize: 11,
    marginBottom: 4,
    letterSpacing: 1,
  },
  statValor: {
    color: '#f0c040',
    fontSize: 22,
    fontWeight: 'bold',
  },
  divisor: {
    width: 1,
    height: 30,
    backgroundColor: '#333',
  },
  vazio: {
    marginTop: 60,
  },
  vazioTexto: {
    color: '#444',
    fontSize: 14,
  },
});